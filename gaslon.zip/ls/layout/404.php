<!doctype html>
<html class="no-js" lang="en">

<body>
    <div class="error-area ptb--100 text-center">
        <div class="container">
            <div class="error-content">
                <h2>404</h2>
                <p>Ooops! Something went wrong .</p>
                <a href="index.php?page=dashboard1">Back to Dashboard</a>
            </div>
        </div>
    </div>
</body>

</html>