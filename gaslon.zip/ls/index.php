<?php
	include "content/index.php";
?>